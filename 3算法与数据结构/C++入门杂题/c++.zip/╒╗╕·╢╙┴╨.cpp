#include<iostream>
#include<cstring>
#define max 100
int s[max];
using namespace std;
//ջ
void push1(int k1) {
	for(int i=max-1; i>=0; i--) {
		if(s[i]==0) {
			s[i]=k1; 
			break;
		}
	}
	return;
}
void pop1() {
	for(int j=0; j<max; j++) {
		if(s[j]!=0) {
			s[j]=0;
			break;
		}
		cout<<"error";
	}
   return;
}
void push2(int k2){
	for(int i=0; i<max; i++) {
		if(s[i]==0) {
			s[i]=k2; 
			break;
		}
	}
	return;
	
}
void pop2(){
	for(int j=0; j<max; j++) {
		if(s[j]!=0) {
			s[j]=0;
			break;
		}
		cout<<"error";
	}
   return;
}
int main(){
	memset(s,0,sizeof(s));
	push1(1);
	push1(2);
	pop1;
	return 0;
}
